import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MathQuizGame implements Game {
    private int score;
    private int currentLevel;

    @Override
    public String getGameName() {
        return "Math Quiz Game";
    }

    @Override
    public void play() {
        Scanner scanner = new Scanner(System.in);
        currentLevel = 1;
        score = 0;

        while (true) {
            System.out.println("Level " + currentLevel);
            double num1 = generateNumber(currentLevel);
            double num2 = generateNumber(currentLevel);

            int operation = generateOperation();
            String operationSymbol = getOperationSymbol(operation);
            double result = calculateResult(num1, num2, operation);

            System.out.println("What is " + num1 + " " + operationSymbol + " " + num2 + "?");
            double answer = scanner.nextDouble();
            scanner.nextLine(); // consume the newline

            if (answer == result) {
                score++;
                System.out.println("Correct! Your score is: " + score);
            } else {
                System.out.println("Wrong answer. The correct answer was " + result);
            }

            if (score == currentLevel) {
                System.out.println("Congratulations! Level " + currentLevel + " completed.");
                currentLevel++;
            }

            System.out.println("Do you want to continue to the next level? (yes/no)");
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("no")) {
                break;
            }
        }

        System.out.println("Game over. Your final score is: " + score);
    }

    @Override
    public String getScore() {
        return String.valueOf(score);
    }

    @Override
    public void writeHighScore(File f) {
        try (FileWriter fw = new FileWriter(f, true)) {
            fw.write(this.getGameName() + "," + this.getScore() + "\n");
        } catch (IOException e) {
            System.out.println("An error occurred while writing high score to file.");
            e.printStackTrace();
        }
    }

    private double generateNumber(int level) {
        double base = 10.0 * level;
        return Math.random() * base;
    }

    private int generateOperation() {
        return (int) (Math.random() * 4); // 0: addition, 1: subtraction, 2: multiplication, 3: division
    }

    private String getOperationSymbol(int operation) {
        switch (operation) {
            case 0:
                return "+";
            case 1:
                return "-";
            case 2:
                return "*";
            case 3:
                return "/";
            default:
                return "";
        }
    }

    private double calculateResult(double num1, double num2, int operation) {
        switch (operation) {
            case 0:
                return num1 + num2;
            case 1:
                return num1 - num2;
            case 2:
                return num1 * num2;
            case 3:
                return num1 / num2;
            default:
                return 0.0;
        }
    }
}