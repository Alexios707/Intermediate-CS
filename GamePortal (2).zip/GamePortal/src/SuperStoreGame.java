import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class SuperStoreGame implements Game {
    @Override
    public String getGameName() {
        return "SuperStoreGame";
    }

    @Override
    public void play() {
        Store store = new Store();
        store.addItem(new Misc("Poles", "Misc", 50, 30));
        store.addItem(new Tech("Helmet", "Tech", 80, 75));
        store.addItem(new Tech("Goggles", "Tech", 40, 30));
        store.addItem(new Equipment("Jacket", "Equipment", 150, 125));
        store.addItem(new Equipment("Pants", "Equipment", 120, 110));
        store.addItem(new Misc("Gloves", "Misc", 30, 25));
        store.addItem(new Misc("Socks", "Misc", 10, 5));
        store.addItem(new Misc("Handwarmers", "Misc", 5, 4));
        store.addItem(new Skis("ArmadaARV96", "Skis", 399.99, 300.0));
        store.addItem(new Skis("BentChetlerskis", "Skis", 599.99, 400.0));
        store.addItem(new Snowboard("BurtonSnowboard", "Snowboard", 300.0, 259.99));
        store.addItem(new SkiBoots("K2RevolverBoots", "Ski boots", 259.99, 199.99));
        store.addItem(new Skis("LineSkis", "Skis", 659.99, 500.0));
        store.addItem(new Skis("K2PoacherSkis", "Skis", 500.0, 399.99));
        store.addItem(new Snowboard("JonesMountainTwinSnowboard", "Snowboard", 600.0, 500.0));
        store.addItem(new Snowboard("CardiffLynxSnowboard", "Snowboard", 399.99, 300.0));
        store.addItem(new SkiBoots("Atomicskiboots", "Ski boots", 400.0, 259.99));
        store.addItem(new SkiBoots("Rossignolskiboots", "Ski boots", 199.99, 99.99));

        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter your name: ");
            String playerName = scanner.nextLine();

            System.out.print("Enter your starting money: ");
            int playerMoney = scanner.nextInt();
            scanner.nextLine();

            Player player = new Player(playerName, playerMoney);
            store.updateSalePrices();
            store.displayInventory();

            while (true) {
                System.out.println("\nWhat do you want to do?");
                System.out.println("1. Buy an item");
                System.out.println("2. Display your inventory");
                System.out.println("3. Display the store's inventory");
                System.out.println("4. Back to menu");

                int choice = scanner.nextInt();
                scanner.nextLine();

                if (choice == 1) {
                    System.out.print("Enter the name of the item you want to buy: ");
                    String itemName = scanner.nextLine();
                    Item item = store.findItemByName(itemName);

                    if (item != null) {
                        player.buyItem(store, item);
                    } else {
                        System.out.println("Sorry, we don't have that item.");
                    }
                } else if (choice == 2) {
                    player.displayInventory();
                } else if (choice == 3) {
                    store.displayInventory();
                } else if (choice == 4) {
                    break;
                } else {
                    System.out.println("Invalid choice.");
                }
            }
        }
    }

    @Override
    public String getScore() {
        return null;
        // Existing code
    }

    @Override
    public void writeHighScore(File file) {
        // Existing code
    }

    class Player {
        private String name;
        private int money;
        private ArrayList<Item> inventory;

        public Player(String name, int money) {
            this.name = name;
            this.money = money;
            this.inventory = new ArrayList<>();
        }

        public void buyItem(Store store, Item item) {
            if (item.getCostPrice() <= this.money) {
                this.money -= item.getCostPrice();
                this.inventory.add(item);
                store.sellItem(item);
                System.out.println(this.name + " bought " + item.getName() + " for $" + item.getCostPrice());
            } else {
                System.out.println(this.name + " doesn't have enough money to buy " + item.getName() + ".");
            }
        }

        public void displayInventory() {
            System.out.println(this.name + " has this much money left: $" + this.money);
            if (this.inventory.size() == 0) {
                System.out.println(this.name + " has no items.");
            } else {
                System.out.println(this.name + "'s inventory:");
                for (Item item : this.inventory) {
                    System.out.println("  " + item.getName() + " (" + item.getCategory() + ")");
                }
            }
        }
    }

    class Store {
        private ArrayList<Item> inventory;

        public Store() {
            this.inventory = new ArrayList<>();
        }

        public void addItem(Item item) {
            this.inventory.add(item);
        }

        public Item findItemByName(String itemName) {
            for (Item item : this.inventory) {
                if (item.getName().equalsIgnoreCase(itemName)) {
                    return item;
                }
            }
            return null;
        }

        public void displayInventory() {
            if (this.inventory.size() == 0) {
                System.out.println("The store has no items.");
            } else {
                System.out.println("The store's inventory:");
                for (Item item : this.inventory) {
                    System.out.println("  " + item.getName() + " (" + item.getCategory() + "): $" + item.getCostPrice());
                }
            }
        }

        public void sellItem(Item item) {
            this.inventory.remove(item);
        }

        public void updateSalePrices() {
            for (Item item : this.inventory) {
                item.getSalePrice();
            }
        }
    }

    class Item {
        private String name;
        private String category;
        private double price;
        private double salePrice;
        private double discountPercentage;

        public Item(String name, String category, double price, double salePrice) {
            this.name = name;
            this.category = category;
            this.price = price;
            this.salePrice = salePrice;
            this.discountPercentage = 0;
        }

        public String getName() {
            return this.name;
        }

        public String getCategory() {
            return this.category;
        }

        public double getPrice() {
            return this.price;
        }

        public double getSalePrice() {
            return this.salePrice;
        }

        public double getCostPrice() {
            Random random = new Random();
            double costPrice;
            if (random.nextDouble() < 0.5) { // 50% chance of being on sale
                costPrice = this.salePrice; // Use                
                costPrice = this.salePrice; // Use the sale price set in the constructor
            } else {
                costPrice = this.price; // Use the regular price
            }
            costPrice -= costPrice * (this.discountPercentage / 100); // Apply discount if set
            return costPrice;
        }

        public void setDiscountPercentage(double discountPercentage) {
            this.discountPercentage = discountPercentage;
        }
    }

    class Tech extends Item {
        public Tech(String name, String category, double price, double salePrice) {
            super(name, category, price, salePrice);
        }

        // Additional methods or properties specific to Tech items can be added here

        @Override
        public double getCostPrice() {
            Random random = new Random();
            if (random.nextDouble() < 0.5) { // 50% chance of being on sale
                return super.getSalePrice(); // Use the sale price set in the constructor
            } else {
                return super.getCostPrice(); // Use the regular price
            }
        }
    }

    class Snowboard extends Item {
        public Snowboard(String name, String category, double price, double salePrice) {
            super(name, category, price, salePrice);
        }

        @Override
        public double getCostPrice() {
            Random random = new Random();
            if (random.nextDouble() < 0.5) { // 50% chance of being on sale
                return super.getSalePrice(); // Use the sale price set in the constructor
            } else {
                return super.getCostPrice(); // Use the regular price
            }
        }
    }

    class Skis extends Item {
        public Skis(String name, String category, double price, double salePrice) {
            super(name, category, price, salePrice);
        }

        @Override
        public double getCostPrice() {
            Random random = new Random();
            if (random.nextDouble() < 0.5) { // 50% chance of being on sale
                return super.getSalePrice(); // Use the sale price set in the constructor
            } else {
                return super.getCostPrice(); // Use the regular price
            }
        }
    }

    class SkiBoots extends Item {
        public SkiBoots(String name, String category, double price, double salePrice) {
            super(name, category, price, salePrice);
        }

        @Override
        public double getCostPrice() {
            Random random = new Random();
            if (random.nextDouble() < 0.5) { // 50% chance of being on sale
                return super.getSalePrice(); // Use the sale price set in the constructor
            } else {
                return super.getCostPrice(); // Use the regular price
            }
        }
    }

    class Misc extends Item {
        public Misc(String name, String category, double price, double salePrice) {
            super(name, category, price, salePrice);
        }

        // Additional methods or properties specific to Misc items can be added here

        @Override
        public double getCostPrice() {
            Random random = new Random();
            if (random.nextDouble() < 0.5) { // 50% chance of being on sale
                return super.getSalePrice(); // Use the sale price set in the constructor
            } else {
                return super.getCostPrice(); // Use the regular price
            }
        }
    }
    class Equipment extends Item {
        public Equipment(String name, String category, double price, double salePrice) {
            super(name, category, price, salePrice);
        }
    
        @Override
        public double getCostPrice() {
            Random random = new Random();
            if (random.nextDouble() < 0.5) { // 50% chance of being on sale
                return super.getSalePrice(); // Use the sale price set in the constructor
            } else {
                return super.getCostPrice(); // Use the regular price
            }
        }
    }
}





