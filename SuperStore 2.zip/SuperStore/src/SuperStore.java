import java.util.ArrayList;
import java.util.Scanner;

// main class
public class SuperStore {
    public static void main(String[] args) {
        // create a new store and add items to its inventory
        Store store = new Store();
        store.addItem(new Item("Poles", "Misc", 50, 30));
        store.addItem(new Item("Helmet", "Tech", 80, 75));
        store.addItem(new Item("Goggles", "Tech", 40, 30));
        store.addItem(new Item("Jacket", "Equipment", 150, 125));
        store.addItem(new Item("Pants", "Equipment", 120, 110));
        store.addItem(new Item("Gloves", "Misc", 30, 25));
        store.addItem(new Item("Socks", "Misc", 10, 5));
        store.addItem(new Item("Handwarmers", "Misc", 5, 4));
        store.addItem(new Item("ArmadaARV96", "Skis", 399.99, 300.0));
        store.addItem(new Item("BentChetlerskis", "Skis", 599.99, 400.0));
        store.addItem(new Item("BurtonSnowboard", "Snowboard", 300.0, 259.99));
        store.addItem(new Item("K2RevolverBoots", "Ski boots", 259.99, 199.99));
        store.addItem(new Item("LineSkis", "Skis", 659.99, 500.0));
        store.addItem(new Item("K2PoacherSkis", "Skis", 500.0, 399.99));
        store.addItem(new Item("JonesMountainTwinSnowboard", "Snowboard", 600.0, 500.0));
        store.addItem(new Item("CardiffLynxSnowboard", "Snowboard", 399.99, 300.0));
        store.addItem(new Item("Atomicskiboots", "Ski boots", 400.0, 259.99));
        store.addItem(new Item("Rossignolskiboots", "Ski boots", 199.99, 99.99));

        // get player's name and starting money from the user
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter your name: ");
            String playerName = scanner.nextLine();

            System.out.print("Enter your starting money: ");
            int playerMoney = scanner.nextInt();

            // create a new player with the given name and money
            Player player = new Player(playerName, playerMoney);

            // update the sale prices of the store's items and display the store's inventory
            store.updateSalePrices();
            store.displayInventory();

            // main game loop
            while (true) {
                // display the options for the player
                System.out.println("\nWhat do you want to do?");
                System.out.println("1. Buy an item");
                System.out.println("2. Display your inventory");
                System.out.println("3. Display the store's inventory");
                System.out.println("4. Quit");

                int choice = scanner.nextInt();

                if (choice == 1) {
                    // ask the player which item they want to buy
                    System.out.print("Enter the name of the item you want to buy: ");
                    String itemName = scanner.next();
                    Item item = store.findItemByName(itemName);

                    // if the item is found, let the player buy it
                    if (item != null) {
                        player.buyItem(store, item);
                    } else {
                        System.out.println("Sorry, we don't have that item.");
                    }
                } else if (choice == 2) {
                    player.displayInventory();
                } else if (choice == 3) {
                    store.displayInventory();
                } else if (choice == 4) {
                    break;
                } else {
                    System.out.println("Invalid choice.");
                }
            }
        }
    }
}
// set up class for the player and user inputs
class Player {
    private String name;
    private int money;
    private ArrayList<Item> inventory;

    public Player(String name, int money) {
        this.name = name;
        this.money = money;
        this.inventory = new ArrayList<>();
    }
    // This allows for the players inventory to change and amount of money remaining to change once the player buys an item
    public void buyItem(Store store, Item item) {
        if (item.getSalePrice() <= this.money) {
            this.money -= item.getSalePrice();
            this.inventory.add(item);
            store.sellItem(item);
            System.out.println(this.name + " bought " + item.getName() + " for $" + item.getSalePrice());
        } else {
            System.out.println(this.name + " doesn't have enough money to buy " + item.getName() + ".");
        }
    }

    public void displayInventory() {
        System.out.println(this.name + " has this much money left : $" + this.money);
        if (this.inventory.size() == 0) {
            System.out.println(this.name + " has no items.");
        } else {
            System.out.println(this.name + "'s inventory:");
            for (Item item : this.inventory) {
                System.out.println("  " + item.getName() + " (" + item.getCategory() + ")");
            }
        }
    }
}
//sets up class for the store and all the items within it
class Store {
    private ArrayList<Item> inventory;

    public Store() {
        this.inventory = new ArrayList<>();
    }

    public void addItem(Item item) {
        this.inventory.add(item);
    }
    //give the item to the player after buying it or say that it is not possible
    public Item findItemByName(String itemName) {
        for (Item item : this.inventory) {
            if (item.getName().equalsIgnoreCase(itemName)) {
                return item;
            }
        }
        return null;
    }
    // command to display the amount of money and inventory items the player has
    public void displayInventory() {
        if (this.inventory.size() == 0) {
            System.out.println("The store has no items.");
        } else {
            System.out.println("The store's inventory:");
            for (Item item : this.inventory) {
                System.out.println(
                        "  " + item.getName() + " (" + item.getCategory() + "): $" + item.getSalePrice());
            }
        }
    }
    //sell the item
    public void sellItem(Item item) {
        this.inventory.remove(item);
    }
    //changes the prices to sale price
    public void updateSalePrices() {
        for (Item item : this.inventory) {
            item.getSalePrice();
        }
    }
}
