public class Item {
    
    // Private instance variables to store item name, category, cost price, and sale price.
    private String name;
    private String category;
    private double costPrice;
    private double salePrice;

    // Constructor method to initialize the Item object with name, category, cost price, and sale price.
    public Item(String name, String category, double costPrice, double salePrice) {
        this.name = name;
        this.category = category;
        this.costPrice = costPrice;
        this.salePrice = salePrice;
    }

    // Empty constructor method with no arguments.
    public Item(String string, String string2, int i) {
        // This constructor method is not used, and does not set any values for the instance variables.
    }

    // Public method to return the sale price of the item.
    public double getSalePrice() {
        return this.salePrice;
    }

    // Public method to return the name of the item.
    public String getName() {
        return this.name;
    }

    // Public method to return the category of the item.
    public String getCategory() {
        return this.category;
    }

    // Public method to update the sale price of the item.
    public void updateSalePrice(double newSalePrice) {
        this.salePrice = newSalePrice;
    }

    // Public method to return the cost price of the item.
    public double getCostPrice() {
        return this.costPrice;
    }

    // Public method to calculate and return the profit of the item.
    public double calculateProfit() {
        return this.salePrice - this.costPrice;
    }
}